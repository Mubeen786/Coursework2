package STEP1;

//By Mubeen B00369506

import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;

//setting name as string in class company

public class Company {
	
    private String name;
    private Queue<Project> projects = new LinkedList<>();
    
    public Company(String name) {
        this.name = name;
    }
//shortening project name to p and adding print line to display success message
    
    public void addProject(Project p){
    	
        this.projects.add(p);
        
        System.out.println("Your new Project was added ThankYou");
    }
// when user chooses remove project it gives message of success or not found
    
    public boolean removeProject(Project p){
    	
        if(this.projects.remove(p)){
        	
            System.out.println(p.getTitle() + " Was Deleted ");
            return true;
            
        } else {
        	
            System.out.println(p.getTitle() + " Was unfortunatley not found");
            return false;
        }
    }
//system tries to finds the project by title and displays not found
    
    public void findAndDisplayByTitle(String s){
    	
        Project p = findProjectByTitle(s);
        
        System.out.println(p!=null?("TITLE\t\t\t\t\tMEMBERS\n"+p.toString()):"Project " + s + " Was unfortunatley not found");
    }

    public Project findProjectByTitle(String s){
    	
        for (Project p: projects) {
        	
            if(p.getTitle().toLowerCase().equals(s.toLowerCase())) return p;
        }
        return null;
    }

    public void displayProject(String title){
    	
        System.out.println(findProjectByTitle(title));
    }

    public void displayProject(Project p){
    	
        System.out.println(p.toString());
    }
//system will display all projects
    
    public void displayAllProjects(){
    	
        System.out.println("TITLE\t\t\t\t\tMEMBERS");
        
        Arrays.sort(projects.toArray());
        
        for(Project p : projects) System.out.println(p.toString());
    }
//get name is set as string
    
    public String getName() {
    	
        return name;
    }
// we have set the name
    
    public void setName(String name) {
    	
        this.name = name;
    }
// this will get project
    
    public Queue<Project> getProjects() {
    	
        return projects;
    }
// this will set project
    
    public void setProjects(Queue<Project> projects) {
    	
        this.projects = projects;
    }
}
