package STEP2;

//By Mubeen B00369506

public class TeamMember implements Comparable<TeamMember> {

	// this is setting employee and division and id to string
	
    private String employeename, divisionname, id;

    public TeamMember(String employeename, String divisionname, String id) {
    	
        this.employeename = employeename;
        this.divisionname = divisionname;
        this.id = id;
        
    }
// this is the compareTo method for team member
    
    @Override
    public int compareTo(TeamMember teamMember) {
    	
        return this.employeename.compareTo(teamMember.employeename);
    }
    
//getter for employee name
    
    public String getEmployeename() {
    	
        return employeename;
    }
// setter for employee name
    
    public void setEmployeename(String employeename) {
    	
        this.employeename = employeename;
    }
// getter for divison name
    
    public String getDivisionname() {
    	
        return divisionname;
    }
    
// settter for divison name
    
    public void setDivisionname(String divisionname) {
    	
        this.divisionname = divisionname;
    }
// getter for get id is string
    
    public String getId() {
    	
        return id;
    }

// setter for set id
    
    public void setId(String id) {
    	
        this.id = id;
    }
    @Override
    public String toString() {
    	
        return employeename + " " + id + " " + divisionname;
    }
}
