package STEP2;

//By Mubeen B00369506

import java.util.Scanner;

// team member test class

public class TeamMemberTest {

    private static Company company = new Company("Test Company");
    
// basic menu for team member
    
    public static void main(String[] args) {
        while (true){
            switch (menu("MAIN MENUE", "Would you like to Add a TeamMember", 
            		"Would you like to Remove a TeamMember",
            		"Would you like to Display a TeamMembers",
            		"Would you like to Find a Specific TeamMember")){
                case 0:
                    System.exit(0);
                    
                case 1:
                    company.addTeamMember(new TeamMember(getString("Hi can you please input TeamMember name"),
                            getString("Hi can you please enter Team Division Name"),
                            getString("Hi can you please enter Team Member ID")));
                    break;
                    
                case 2:
                    company.removeTeamMember(company.findTeamMemberByName(getString("Hi can you please  enter name of team member to remove")));
                    break;
                    
                case 3:
                    company.displayAllTeamMembers();
                    break;
                    
                case 4:
                    company.findAndDisplayTeamMemberByName(getString("Hi can you please  enter a team member name"));
                    break;
            }
        }
    }

    private static int menu(String prompt, String... options){
    	
        System.out.println(" -- " + prompt + " -- ");
        int k = 1;
        for(String s : options){
        	
            System.out.println(k++ + ") "+ s);
        }
        
        System.out.print("0) Quit\n> ");

        String response = new Scanner(System.in).nextLine();
        
        try {
            int responseInt = Integer.valueOf(response);
            
            if(responseInt >= 0 || responseInt <= k) return responseInt;
            
            else throw new Exception();
            
        } catch (Exception e){
        	
        	// catches any invalid input
        	
            System.out.println("Error: Invalid Entry");
            
            return menu(prompt, options);
        }
    }

    private static String getString(String prompt){
    	
        System.out.print(prompt + "\n> ");
        return new Scanner(System.in).nextLine();
    }
// this will tell user to input integer
    
    private static int getInt(String prompt){
    	
        try {
        	
            return Integer.valueOf(getString(prompt));
            
        } catch (Exception e){
        	
            System.out.println(" Hi can you please enter an integer");
            
            return getInt(prompt);
        }
    }

}
