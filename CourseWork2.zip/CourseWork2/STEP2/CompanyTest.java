package STEP2;

//By Mubeen B00369506

import java.util.Scanner;

public class CompanyTest {

    private static Company company = new Company("Testing Company");
    
// this is a basic menu for projects
    
    public static void main(String[] args) {
        while (true){
            switch (menu("MAIN MENUE", "Would you like to Add a Project", 
            		"Would you like to Remove a Project", 
            		"Would you like to Display Projects",
            		"Would you like to Find a project")){
                case 0:
                    exit();
                case 1:
                    company.addProject(new Project(getString("Hi can you please input a project title")));
                    break;
                case 2:
                    company.removeProject(company.findProjectByTitle(getString("Hi can you please input title of project to remove")));
                    break;
                case 3:
                    company.displayAllProjects();
                    break;
                case 4:
                    company.findAndDisplayByTitle(getString("Hi can you please input project title"));
                    break;
            }
        }
    }



    private static int menu(String prompt, String... options){
    	
        System.out.println(" -- " + prompt + " -- ");
        int k = 1;
        
        for(String s : options){
        	
            System.out.println(k++ + ") "+ s);
        }
        
        System.out.print("0) Quit\n> ");

        String response = new Scanner(System.in).nextLine();
        
        try {
        	
            int responseInt = Integer.valueOf(response);
            
            if(responseInt >= 0 || responseInt <= k) return responseInt;
            
            else throw new Exception();
            
        } catch (Exception e){
        	
        	//this catches if the user enters wrong digit and displays error
        	
            System.out.println("Error: Invalid Entry");
            return menu(prompt, options);
        }
    }

    private static String getString(String prompt){
    	
        System.out.print(prompt + "\n> ");
        
        return new Scanner(System.in).nextLine();
        
    }
 // this will ask user for yes or no if they wish to quit
    
    private static void exit(){
    	
        if(getString("Do you really want to exit? (y/n)").equals("y")){
        	
            System.exit(1);
        }
    }
}
