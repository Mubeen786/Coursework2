package STEP2;

//By Mubeen B00369506

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;

public class Company {
	
    private String name;
    private Queue<Project> projects = new LinkedList<>();
    private ArrayList<TeamMember> teamMembers = new ArrayList<>();

    public Company(String name) {
        this.name = name;
        
// these are test projects
        
        this.addProject(new Project("Testing Testing Project 1"));
        
        this.addProject(new Project("Testing Testing Project 2"));
        
        this.addProject(new Project("Testing Testing Project 3"));
    }
// this is add team member method
    
    public void addTeamMember(TeamMember teamMember){
    	
        this.teamMembers.add(teamMember);
    }
// this is where user picks to remove team member and displays success message
    
    public boolean removeTeamMember(TeamMember teamMember){
    	
        if(this.teamMembers.remove(teamMember)){
        	
            System.out.println(teamMember.getEmployeename() + " The employee was removed");
            return true;
            
        } else {
        	
            System.out.println(teamMember.getEmployeename() + " Unfortunetly the empolyee was not found");
            return false;
        }
    }
// this will display all team members
    
    public void displayAllTeamMembers(){
    	
        System.out.println("NAME\t\t\t\t\tAGE");
        
        Arrays.sort(teamMembers.toArray());
        
        for(TeamMember t : teamMembers) System.out.println(t.toString());
    }

    public TeamMember findTeamMemberByName(String s){
    	
        for (TeamMember t: teamMembers) {
        	
            if(t.getEmployeename().toLowerCase().contains(s.toLowerCase())) return t;
        }
        return null;
    }
// // this will add project with success message
    
    public void addProject(Project p){
    	
        this.projects.add(p);
        
        System.out.println(p.getTitle() + " This was added successfully ");
    }
    
// this will remove project with success or not found message
    public boolean removeProject(Project p){
    	
        if(this.projects.remove(p)){
        	
            System.out.println(p.getTitle() + " This was removed ");
            return true;
            
        } else {
        	
            System.out.println(p.getTitle() + " This was unfortunetly not found");
            return false;
        }
    }
// this will find and display the title
    
    public void findAndDisplayByTitle(String s){
    	
        Project p = findProjectByTitle(s);
        
        System.out.println(p!=null?("TITLE\t\t\t\t\tMEMBERS\n"+p.toString()):"Project " + s + " sorry not found");
    }

    public Project findProjectByTitle(String s){
    	
        for (Project p: projects) {
        	
            if(p.getTitle().toLowerCase().equals(s.toLowerCase())) return p;
        }
        return null;
    }
// this will display all projects
    
    public void displayAllProjects(){
    	
        System.out.println("TITLE\t\t\t\t\tMEMBERS");
        
        Arrays.sort(projects.toArray());
        
        for(Project p : projects) System.out.println(p.toString());
    }
// this will find team member by name
    
    public void findAndDisplayTeamMemberByName(String string) {
    	
        TeamMember t = findTeamMemberByName(string);
        
        System.out.println(t!=null?("NAME\t\t\t\t\tAGE\n"+t.toString()):"Team Member " + t + " Unfrotunetly not found");
    }
}
