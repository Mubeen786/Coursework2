package STEP2;

//By Mubeen B00369506

import java.util.Date;

//this is the project class with string title and start and end date

public class Project implements Comparable<Project> {
	
    private String title;
    private Date startDate, endDate;

    public Project(String title, Date startDate, Date endDate) {
    	
        this.title = title;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    @Override
    public String toString() {
        return title;
    }
    
 // this is a compare to method
    
    @Override
    public int compareTo(Project project) {
    	
        return this.title.compareTo(project.title);
    }

    public Project(String title) {
    	
        this.title = title;
    }
 // getter for title
    
    public String getTitle() {
    	
        return title;
    }
// setter for title
    
    public void setTitle(String title) {
    	
        this.title = title;
    }


}
