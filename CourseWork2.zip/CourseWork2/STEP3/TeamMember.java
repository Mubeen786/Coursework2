package STEP3;

//By Mubeen B00369506

public class TeamMember implements Comparable<TeamMember> {

    private String name;
    private int age;

    public TeamMember(String name, int age) {
    	
        this.name = name;
        this.age = age;
    }

    @Override
    public boolean equals(Object obj) {
    	
        try {
        	
            return this.name.equals(((TeamMember) obj).name);
        }
        
        catch (Exception e){
        	
            return false;
        }
    }

    @Override
    public String toString() {
    	
        return name+ "\t\t " + age;
    }

    public String getName() {
    	
        return name;
    }
// this is a compare to method
    @Override
    public int compareTo(TeamMember teamMember) {
    	
        return this.name.compareTo(teamMember.name);
    }
}
