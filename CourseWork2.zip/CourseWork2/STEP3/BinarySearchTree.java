package STEP3;

//By Mubeen B00369506

public class BinarySearchTree<T extends Comparable<T>> {
    private TreeNode<T> root;
    
// this is the add method
    public boolean add(T value){
    	
        if(root == null){
        	
            root = new TreeNode<>(value);
            
            return true;
        }
        
        return root.insert(value);
    }
// this is the remove method
    public void remove(T value){
    	
        this.root = root.removeNode(root, value);
    }

    @Override
    public String toString() {
    	
        if(root!=null) return root.toString();
        
        else return null;
    }
// this is the run in order method
    public void runInOrder(TreeRunnable treeAction){
    	
        root.runInOrder(root, treeAction);
    }

    public T find(T value){
    	
        return root.find(value);
    }

    public TreeNode getRoot() {
    	
        return root;
    }
}
