package STEP3;

//By Mubeen B00369506

public class Company {
	
    private String name;
    private BinarySearchTree<Project> projects = new BinarySearchTree<>();

    public Company(String name) {
    	
        this.name = name;
    }
// adding team member to the project method
    public void addTeamMemberToProject(Project project, TeamMember teamMember){
    	
        project.addTeamMember(teamMember);
    }
// removing the team member from project method
    public void removeTeamMemberFromProject(Project project, TeamMember teamMember){
    	
        project.removeTeamMember(teamMember);
    }
// this will print team member for project
    public void printTeamMembersForProject(Project project){
    	
        for(TeamMember t : project.getTeamMembers()) System.out.println(t.toString());
    }
// this will add project and display success or no success message
    public void addProject(Project p){
    	
        if(this.projects.add(p))
        	
        System.out.println(p.getTitle() + " this was added successfully");
        
        else System.out.println("Unfrotunelty project already exists with this name");
    }
// this is the remove project method
    public void removeProject(Project p){
    	
        this.projects.remove(p);
    }
// this is find and display by title method
    public void findAndDisplayByTitle(String s){
    	
        Project p = findProjectByTitle(s);
        
        System.out.println(p!=null?("TITLE\t\t\t\t\tMEMBERS\n"+p.toString()):"Project " + s + " not found");
    }
// this is the find project by title method
    public Project findProjectByTitle(String s){
    	
        return projects.find(new Project(s));
    }
// this is the display all projects method
    public void displayAllProjects(){
    	
        String s = projects.toString();
        
        if(s != null)System.out.println("TITLE\t\t\t\t\tMEMBERS\n" + s);
        
        else System.out.println("No Projects");
    }
// this will display the numbers of projects
    public void displayMemberNumbersForAllProjects() {
    	
        System.out.println("TITLE\t\t\tMEMBERS");
        
        projects.runInOrder(new TreeRunnable<Project>() {
        	
            @Override
            public void run() {
            	
                System.out.println(this.getValue().getTitle()+"\t\t"+this.getValue().getTeamSize());
            }
        });
    }
}
