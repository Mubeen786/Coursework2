package STEP3;
import java.util.Scanner;

//By Mubeen B00369506


public class Step3Test {
    private static Company company = new Company("Test Company");
// this is the main menu
    public static void main(String[] args) {
        while (true){
            switch (menu("MAIN MENUE",
                    "Would you like to Add Project",
                    "Would you like to Add Team Member",
                    "Would you like to Would you like to Remove Team Member",
                    "Would you like to Remove Project",
                    "Would you like to Display All Team Members For Project",
                    "Would you like to Display All Projects",
                    "Would you like to Display Number of Team Members in Each Project")){
                case 0:
                    System.exit(0);
                case 1:
                    company.addProject(new Project(getString("Hi can you please enter project title")));
                    break;
                case 2:
                    company.addTeamMemberToProject(
                            company.findProjectByTitle(getString("Hi can you please enter title of project to add team member to")),
                            new TeamMember(getString("please enter Team Member Name"), getInt("please enter Team Member Age"))
                    );
                    break;
                case 3:
                    company.removeTeamMemberFromProject(
                            company.findProjectByTitle(getString("Hi can you please enter title of project to remove team member from")),
                            new TeamMember(getString("Enter Team Member Name"),0)
                    );
                    break;
                case 4:
                    Project project = company.findProjectByTitle(getString("Hi can you please enter title of project to remove"));
                    
                    if(project != null){
                        company.removeProject(project);
                        System.out.println(project.getTitle() + " successfully removed");
                        
                    }
                    else System.out.println("Unfortunetly project not found");
                    break;
                    
                case 5:
                    company.findAndDisplayByTitle(getString("Hi can you please enter project title"));
                    break;
                    
                case 6:
                    company.displayAllProjects();
                    break;
                    
                case 7:
                    company.displayMemberNumbersForAllProjects();
                    break;
            }
        }
    }

    private static int menu(String prompt, String... options){
    	
        System.out.println(" -- " + prompt + " -- ");
        int k = 1;
        
        for(String s : options){
        	
            System.out.println(k++ + ") "+ s);
        }
        
        System.out.print("0) Quit\n> ");

        String response = new Scanner(System.in).nextLine();
        try {
        	
            int responseInt = Integer.valueOf(response);
            
            if(responseInt >= 0 || responseInt <= k) return responseInt;
            
            else throw new Exception();
            
        } 
        // this is catch
        catch (Exception e){
        	
            System.out.println("Error: Invalid entry");
            
            return menu(prompt, options);
        }
    }

    private static String getString(String prompt){
    	
        System.out.print(prompt + "\n> ");
        
        return new Scanner(System.in).nextLine();
    }

    private static int getInt(String prompt){
    	
        try {
        	
            return Integer.valueOf(getString(prompt));
            
        } 
        // this is a catch
        catch (Exception e){
        	
            System.out.println("Please enter an integer");
            
            return getInt(prompt);
        }
    }
}
