package STEP3;

//By Mubeen B00369506

public class TreeNode<T extends Comparable<T>> {
	
    private T value;
    public TreeNode<T> left;
    public TreeNode<T> right;

    public TreeNode(T value) {
    	
        this.value = value;
    }
// THIS IS A RUN IN ORDER METHOD
    public void runInOrder(TreeNode<T> root, TreeRunnable treeAction){
    	
        if(root.left!=null) runInOrder(root.left, treeAction);
        
        treeAction.setValue(root.value);
        
        treeAction.run();
        
        if(root.right!=null) runInOrder(root.right, treeAction);
    }

    @Override
    public String toString() {
    	
        String s = "";
        if(left != null) s += left.toString() + "\n";
        s += this.value.toString() + "\n";
        if(right != null) s += right.toString() + "\n";
        return s;
    }

    public boolean hasNext(){
    	
        return this.left != null || this.right != null;
    }

    public T getValue() {
    	
        return this.value;
    }

    public T find(T value){
    	
        if(this.value.equals(value)) return this.value;
        T leftFind = null, rightFind = null;
        
        if(this.left != null) if(this.value.compareTo(value) > 0) leftFind = left.find(value);
        
        if(leftFind != null) return leftFind;
        
        if(this.right != null) if(this.value.compareTo(value) < 0) rightFind = right.find(value);
        
        if(rightFind != null) return rightFind;
        
        else return null;
    }

    public boolean insert(T value){
    	
        if(this.value.compareTo(value) > 0) {
        	
            if (this.left == null) {
            	
                this.left = new TreeNode<>(value);
                
                return true;
                
            } 
            
            else this.left.insert(value);
        }
        
        if(this.value.compareTo(value) < 0) {
        	
            if (this.right == null) {
            	
                this.right = new TreeNode<>(value);
                
                return true;
                
            } 
            
            else this.right.insert(value);
        }
        
        return false;
    }
// this is the remove node
    public TreeNode<T> removeNode(TreeNode<T> root, T value) {
    	
        if (root == null)  return root;
        
        if (this.value.compareTo(value) < 0)
        	
            root.left = removeNode(root.left, value);
        
        else if (this.value.compareTo(value) > 0)
        	
            root.right = removeNode(root.right, value);
        
        else{
        	
            if (root.left == null) return root.right;
            
            else if (root.right == null) return root.left;
            
            root.value = findMinNode(root.right).value;
            
            root.right = removeNode(root.right, root.value);
        }
        
        return root;
    }
// this is find minimum node
    public TreeNode<T> findMinNode(TreeNode<T> root) {
    	
        if(root.left != null) return findMinNode(root.left);
        
        else return root;
    }

}
