package STEP3;
import java.util.ArrayList;
import java.util.Arrays;

//By Mubeen B00369506


public class Project implements Comparable<Project> {
	
    private String title;
    private ArrayList<TeamMember> teamMembers = new ArrayList<>();

    public Project(String title) {
    	
        this.title = title;
    }

    @Override
    public boolean equals(Object obj) {
    	
        try {
        	
            return this.title.equals(((Project) obj).title);
            
        }
        
        catch (Exception e){
        	
            return false;
        }
    }

    @Override
    public String toString() {
    	
        String s = title;
        if(teamMembers.isEmpty()) {
        	
            s += "\t\t No Members";
        }
        else {
        	
            s+="\t\t";
            
            for (TeamMember t : teamMembers) {
            	
                s += " " + t.getName() + " ";
            }
        }
        
        return s;
    }
// this is compareto method
    @Override
    public int compareTo(Project project) {
    	
        return this.title.compareTo(project.title);
    }
// this is the get team size method
    public int getTeamSize(){
    	
        return this.teamMembers.size();
    }
// this is the add team meber method
    public void addTeamMember(TeamMember teamMember) {
    	
        this.teamMembers.add(teamMember);
    }
//this is the remove team member method
    public boolean removeTeamMember(TeamMember teamMember){
    	
        if(this.teamMembers.remove(teamMember)){
        	
            System.out.println(teamMember.getName() + " removed successfully");
            
            return true;
            
        } 
        
        else {
        	
            System.out.println(teamMember.getName() + " Unfrotunetly not found");
            
            return false;
        }
    }
// this will display all team members
    public void displayAllTeamMembers(){
    	
        System.out.println("NAME\t\t\t\t\tAGE");
        
        Arrays.sort(teamMembers.toArray());
        
        for(TeamMember t : teamMembers) System.out.println(t.toString());
    }
// this will find team members by name
    public TeamMember findTeamMemberByName(String s){
    	
        for (TeamMember t: teamMembers) {
        	
            if(t.getName().toLowerCase().contains(s.toLowerCase())) return t;
        }
        
        return null;
    }

    public void findAndDisplayTeamMemberByName(String string) {
    	
        TeamMember t = findTeamMemberByName(string);
        
        System.out.println(t!=null?("NAME\t\t\t\t\tAGE\n"+t.toString()):"Team Member " + t + " sorry not found");
    }

    public ArrayList<TeamMember> getTeamMembers() {
    	
        return this.teamMembers;
    }

    public String getTitle() {
    	
        return title;
    }
}
