package STEP3;
import java.util.Scanner;

//By Mubeen B00369506

import static junit.framework.TestCase.assertEquals;

public class CompanyTest {

    private static Company testCompany = new Company("Test Company");
// this is the main menu
    public static void main(String[] args) {
        while (true){
            switch (menu("MAIN MENUE", 
            		"Would you like to Add Project", 
            		"Would you like to Remove Project", 
            		"Would you like to Display Projects", 
            		"Would you like to Find a project")){
                case 0:
                    System.exit(0);
                case 1:
                    testCompany.addProject(new Project(getString("Please input project title")));
                    break;
                case 2:
                    testCompany.removeProject(testCompany.findProjectByTitle(getString("Please input title of project to remove")));
                    break;
                case 3:
                    testCompany.displayAllProjects();
                    break;
                case 4:
                    testCompany.findAndDisplayByTitle(getString("Please input project title"));
                    break;
            }
        }
    }

    private static int menu(String prompt, String... options){
    	
        System.out.println(" -- " + prompt + " -- ");
        
        int k = 1;
        
        for(String s : options){
        	
            System.out.println(k++ + ") "+ s);
        }
        
        System.out.print("0) Quit\n> ");

        String response = new Scanner(System.in).nextLine();
        
        try {
        	
            int responseInt = Integer.valueOf(response);
            
            if(responseInt >= 0 || responseInt <= k) return responseInt;
            
            else throw new Exception();
            
        } 
        catch (Exception e){
        	
            System.out.println("Error: Invalid Entry");
            
            return menu(prompt, options);
        }
    }

    private static String getString(String prompt){
    	
        System.out.print(prompt + "\n> ");
        
        return new Scanner(System.in).nextLine();
    }

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
        testCompany = new Company("Test Company");
    }
// this is the test case
    @org.junit.jupiter.api.Test
    void addTeamMemberToProject() {
        Project testProject = new Project("Test Project");
        testCompany.addProject(testProject);
        TeamMember teamMember1 = new TeamMember("Team Member 1", 30);
        TeamMember teamMember2 = new TeamMember("Team Member 2", 30);
        TeamMember teamMember3 = new TeamMember("Team Member 3", 30);
        testCompany.addTeamMemberToProject(testCompany.findProjectByTitle("Test Project"), teamMember1);
        testCompany.addTeamMemberToProject(testCompany.findProjectByTitle("Test Project"), teamMember2);
        testCompany.addTeamMemberToProject(testCompany.findProjectByTitle("Test Project"), teamMember3);
        assertEquals(teamMember1, testCompany.findProjectByTitle("Test Project").getTeamMembers().get(0));
        assertEquals(teamMember2, testCompany.findProjectByTitle("Test Project").getTeamMembers().get(1));
        assertEquals(teamMember3, testCompany.findProjectByTitle("Test Project").getTeamMembers().get(2));
    }
 // this is the test case
    @org.junit.jupiter.api.Test
    void removeTeamMemberFromProject() {
        Project testProject = new Project("Test Project");
        testCompany.addProject(testProject);
        TeamMember teamMember1 = new TeamMember("Team Member 1", 30);
        TeamMember teamMember2 = new TeamMember("Team Member 2", 30);
        TeamMember teamMember3 = new TeamMember("Team Member 3", 30);
        testCompany.addTeamMemberToProject(testCompany.findProjectByTitle("Test Project"), teamMember1);
        testCompany.addTeamMemberToProject(testCompany.findProjectByTitle("Test Project"), teamMember2);
        testCompany.addTeamMemberToProject(testCompany.findProjectByTitle("Test Project"), teamMember3);
        testCompany.removeTeamMemberFromProject(testProject, teamMember2);
        assertEquals(teamMember1, testCompany.findProjectByTitle("Test Project").getTeamMembers().get(0));
        assertEquals(teamMember3, testCompany.findProjectByTitle("Test Project").getTeamMembers().get(1));
    }
 // this is the test case
    @org.junit.jupiter.api.Test
    void addProject() {
        Project testProject = new Project("Test Project");
        testCompany.addProject(testProject);
        assertEquals(testProject, testCompany.findProjectByTitle("Test Project"));
    }
 // this is the test case
    @org.junit.jupiter.api.Test
    void findProjectByTitle() {
        Project testProject1 = new Project("Test Project 1");
        Project testProject2 = new Project("Test Project 2");
        Project testProject3 = new Project("Test Project 3");
        testCompany.addProject(testProject1);
        testCompany.addProject(testProject2);
        testCompany.addProject(testProject3);
        assertEquals(testProject1, testCompany.findProjectByTitle("Test Project 1"));
        assertEquals(testProject2, testCompany.findProjectByTitle("Test Project 2"));
        assertEquals(testProject3, testCompany.findProjectByTitle("Test Project 3"));
    }
}
