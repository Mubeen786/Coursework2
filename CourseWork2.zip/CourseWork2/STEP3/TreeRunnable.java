package STEP3;

//By Mubeen B00369506

public abstract class TreeRunnable<T> implements Runnable {

    private T value;
// this will set the value
    public void setValue(T value) {
    	
        this.value = value;
    }
// this will get the value
    public T getValue() {
    	
        return value;
    }
}
